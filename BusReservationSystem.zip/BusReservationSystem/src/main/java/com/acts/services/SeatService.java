package com.acts.services;

import com.acts.entities.Seat;

public interface SeatService {
	Seat saveSeat(Seat seat);
}
